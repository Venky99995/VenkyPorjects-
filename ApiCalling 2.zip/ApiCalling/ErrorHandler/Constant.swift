//
//  Constant.swift
//  ApiCalling
//
//  Created by user255655 on 6/17/24.
//

import Foundation

struct constants {
    
    
    
    struct APIS {
        static let Baseurl = "https://api.restful-api.dev"
        static let Products = "/objects"
        static let createproduct = "/objects"
        static let Update  = "/objects/7"
    static let delete = "/objects/6"
    }
    struct APISNAme{
        static let Api_NAme = "Products"
    }
}
