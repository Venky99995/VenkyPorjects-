//
//  AlertHelper.swift
//  ChatTableView
//
//  Created by apple on 16/12/23.
//

import UIKit
import Foundation

// MARK : Corner Radius
protocol ShowCornerRadiusTableviewCell {}

extension ShowCornerRadiusTableviewCell where Self: UITableViewCell
{
    func leftTopLeftBottomCornerRadiusView(view : UIView, width: CGFloat , height: CGFloat , color : UIColor) {
        
        let rectShape = CAShapeLayer()
        rectShape.bounds = view.frame
        rectShape.position = view.center
        rectShape.path = UIBezierPath(roundedRect: view.bounds, byRoundingCorners: [.bottomLeft , .topLeft], cornerRadii: CGSize(width: width, height: height)).cgPath
        
        view.layer.backgroundColor = color.cgColor
        //Here I'm masking the textView's layer with rectShape layer
        view.layer.mask = rectShape
        
    }
}

func isNetworkReachable() -> Bool
{
    if Reachability.isConnectedToNetwork()
    {
        return true
        
    } else {
        
        return false
    }
}

// MARK : Alert
protocol ShowAlert {}

extension ShowAlert where Self: UIViewController
{
    
    
    func showAlert(_ message: String)
    {
        let alertController = UIAlertController(title: constants.APISNAme.Api_NAme, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion:nil)
        
    }
    func showAlertAndDismiss(_ message: String)
    {
        let alert = UIAlertController(title: "", message: message, preferredStyle: .alert)
        self.present(alert, animated: true, completion: nil)
        let when = DispatchTime.now() + 0.8
        DispatchQueue.main.asyncAfter(deadline: when){
            // your code with delay
            alert.dismiss(animated: true, completion: nil)
        }
    }
    func showAlertWithActions(_ message:String) {
        
        let alertController = UIAlertController(title: constants.APISNAme.Api_NAme, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default)
        { action -> Void in
            
            _ = self.navigationController?.popViewController(animated: true)

        })
        present(alertController, animated: true, completion:nil)
    }
    
    
    func showAlertWithActionsMoveToRootView(_ message:String) {
        
        let alertController = UIAlertController(title: constants.APISNAme.Api_NAme, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default)
        { action -> Void in
            
            _ = self.navigationController?.popToRootViewController(animated: false)
            
        })
        present(alertController, animated: true, completion:nil)
    }
    func showAlertWithActionsJumpBackTwoVcs(_ message:String) {
        
        let alertController = UIAlertController(title: constants.APISNAme.Api_NAme, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default)
        { action -> Void in
            
            let controller = self.navigationController!.viewControllers
        self.navigationController!.popToViewController(controller[controller.count - 3], animated: true)
            
        })
        present(alertController, animated: true, completion:nil)
    }
    func  showAlertWithTwoActions(_ message:String) {
        
        let alertController = UIAlertController(title: constants.APISNAme.Api_NAme, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "NO", style: .default, handler: nil))
        alertController.addAction(UIAlertAction(title: "YES", style: UIAlertAction.Style.default)
        { action -> Void in
            
            _ = self.navigationController?.popViewController(animated: true)
            
        })
        present(alertController, animated: true, completion:nil)
        
    }
    
     func dampingEffect(view:UIView) -> Void {
        view.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        UIView.animate(withDuration: 0.5,
                       delay: 0,
                       usingSpringWithDamping: 1.0,
                       initialSpringVelocity: 10.0,
                       options: .allowUserInteraction,
                       animations: { [weak view] in
                        view?.transform = .identity
            },
                       completion: nil)
    }
        
    //MARK:- Logout Message view.
    func logoutAlertViewMessage() {
        
        let alertController = UIAlertController(title: constants.APISNAme.Api_NAme, message: AKErrorHandler.CommonErrorMessages.LOGOUT, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "NO", style: UIAlertAction.Style.default)
        { action -> Void in
            
            
        })
        
        alertController.addAction(UIAlertAction(title: "YES", style: UIAlertAction.Style.default)
        { action -> Void in

            // self.userLogout()
        })
        
        self.present(alertController, animated: true, completion:nil)
        
    }
    

    func leftTopCornerRadiusLabel(label : UILabel, width: CGFloat , height: CGFloat , color : UIColor) {
        
        let rectShape = CAShapeLayer()
        rectShape.bounds = label.frame
        rectShape.position = label.center
        rectShape.path = UIBezierPath(roundedRect: label.bounds, byRoundingCorners: [.topLeft], cornerRadii: CGSize(width: width, height: height)).cgPath
        
        label.layer.backgroundColor = UIColor.green.cgColor
        //Here I'm masking the textView's layer with rectShape layer
        label.layer.mask = rectShape
    }

    func callURL(url : String) {
        
        if let url = URL(string: "tel://\(url)"), UIApplication.shared.canOpenURL(url) {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
        
    }
    
}
