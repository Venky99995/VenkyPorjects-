//
//  FetchProducts.swift
//  ApiCalling
//
//  Created by user255655 on 6/17/24.
//

import Foundation

struct CreateModal: Codable {

    let id: String?
    let name: String?
    let data: Data?

}


struct Data: Codable {

    let color: String?
    let capacity: String?

}
