//
//  ProductTableViewCell.swift
//  ApiCalling
//
//  Created by user255655 on 6/18/24.
//

import UIKit

class ProductTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var NameLabel: UILabel!
    
    @IBOutlet weak var colorLabel: UILabel!
    
    @IBOutlet weak var cpacitylabel: UILabel!
    
   
}
