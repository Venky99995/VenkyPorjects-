//
//  DeleteproductViewModal.swift
//  ApiCalling
//
//  Created by user255655 on 6/18/24.
//

import Foundation
import SVProgressHUD
import Alamofire
class DeleteProductviewModal {
    
   var  deletebody : DeleteMethod?
    
    func deleteproduct(id: Int, completion:@escaping() -> ()){
        
        let sourceurl = constants.APIS.Baseurl + constants.APIS.delete + "/\(id)"
        SVProgressHUD.show()
        AF.request(sourceurl, method: .delete, parameters:nil, encoding: URLEncoding.default, headers: nil,interceptor: nil)
            .response{ resp in
                switch resp.result{
                    
                case .success(let data):
                    do{
                        let deletedata = try JSONDecoder().decode(DeleteMethod.self, from: data!)
                        print("data:\(deletedata)")
                        self.deletebody = deletedata
                        completion()
                        SVProgressHUD.dismiss()
                    }catch{
                        print(error.localizedDescription)
                    }
                case .failure(let error):
                    print(error.localizedDescription)
                }
                
                
            }
        
        
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
}
