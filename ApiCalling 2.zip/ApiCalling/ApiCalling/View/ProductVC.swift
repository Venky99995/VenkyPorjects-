//
//  ProductVC.swift
//  ApiCalling
//
//  Created by user255655 on 6/18/24.
//

import UIKit

class ProductVC: UIViewController ,ShowAlert {

    @IBOutlet weak var TableView: UITableView!
    
    //fetch
    var listproducts : [CreateModal] = []
    var  fetchviewproductList = ListofObjects()
    
    var attachingproduct : PostMethod?
    var AttachingviewModallist = createProductViewmodal()
    
    var Updatedproduct  : UpdateMethod?
    var updateviewlist = updateProductviewmodal()
    
    var deleteproduct : DeleteMethod?
    var deleteviewlist = DeleteProductviewModal()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    
    @IBAction func Addbuttontaped(_ sender: Any) {
        ADDobjects()
    }
    
    
    
    
    @IBAction func UpdateButtontapped(_ sender: Any) {
        showAlertWithTextfield(State: "Update", id: nil)
    }
    
    
    
    @IBAction func DeleteButtonTapped(_ sender: Any) {
        deleteObjetcs()
    }
    
    
    @IBAction func GetButtonTapped(_ sender: Any) {
        fetchListObject()
    }
}

extension ProductVC : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.listproducts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cells = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as!ProductTableViewCell
        cells.NameLabel.text = listproducts[indexPath.row].name
        cells.colorLabel.text = listproducts[indexPath.row].data?.color
        cells.cpacitylabel.text = listproducts[indexPath.row].data?.capacity
        return cells
    }
    
    
    func fetchListObject(){
        if isNetworkReachable(){
            fetchviewproductList.fetchproducts {
                [weak self] in
                self?.listproducts.removeAll()
                self?.listproducts = (self?.fetchviewproductList.productfetch)!
                DispatchQueue.main.async {
                    self?.TableView.reloadData()
                }
            }
        }else{
            self.showAlertWithActions(AKErrorHandler.CommonErrorMessages.NO_INTERNET_AVAILABLE)
        }
    }
    
    func showAlertWithTextfield(State :String, id:Int?){
        let alert = UIAlertController(title: constants.APISNAme.Api_NAme, message: State, preferredStyle: .alert)
        
        alert.addTextField{(textfield) in
            textfield.placeholder = "ID"
        }
        alert.addTextField{(textfield) in
            textfield.placeholder = "name"
        }
        alert.addTextField{(textfield) in
            textfield.placeholder = "year"
        }
        alert.addTextField{(textfield) in
            textfield.placeholder = "price"
        }
        alert.addTextField{(textfield) in
            textfield.placeholder = "Cpumodal"
        }
        alert.addTextField{(textfield) in
            textfield.placeholder = "Hardisksize"
        }
        
        alert.addTextField{(textfield) in
            textfield.placeholder = "color"
        }
        let cancelaction = UIAlertAction(title: "Cancel", style: .cancel)
        let saveaction = UIAlertAction(title: "Save", style: .default){ _ in
            guard  let fetchId = alert.textFields?[0].text, let getId = Int(fetchId) , !fetchId.isEmpty else{
                
                self.showAlert("Id is required")
                return
            }
            guard let fetchname = alert.textFields?[1].text , !fetchname.isEmpty else{
                self.showAlert("name is required")
                return
            }
            guard let fetchyear = alert.textFields?[2].text,!fetchyear.isEmpty else{
                self.showAlert("year is required")
                return
            }
            guard let fetchprice = alert.textFields?[3].text,let getPrice = Double(fetchprice) ,!fetchyear.isEmpty else{
                self.showAlert("price is required")
                return
            }
            guard let fetchCpumodal = alert.textFields?[4].text,!fetchCpumodal.isEmpty else{
                self.showAlert("Cpumodal is required")
                return
            }
            guard let fetchharddisksize = alert.textFields?[5].text,!fetchharddisksize.isEmpty else{
                self.showAlert("hardidskSize is required")
                return
            }
            guard let fetchColor = alert.textFields?[6].text,!fetchColor.isEmpty else{
                self.showAlert("Color is required")
                return
            }
            if isNetworkReachable(){
                switch State{
                    
                case "Update":
                    self.updateviewlist.Updateproduct(id: getId, name: fetchname, year: fetchyear, price: getPrice, CpuModal: fetchCpumodal, HarddiskSize: fetchharddisksize, color: fetchColor){[weak self] in
                        self?.Updatedproduct = self?.updateviewlist.updateproduct
                        DispatchQueue.global().async {
                            self?.fetchListObject()
                            self?.showAlert("updates Successfully")
                        }
                    }
                default:
                    print("Nothing")
                }//closed
                
            }else{
                self.showAlertWithActions(AKErrorHandler.CommonErrorMessages.NO_INTERNET_AVAILABLE)
            }
            
        }
        alert.addAction(saveaction)
        alert.addAction(cancelaction)
        self.present(alert, animated: true, completion: nil)
        
    }
    func deleteObjetcs(){
        guard !listproducts.isEmpty else{
            showAlert("No users are available''")
            return
        }
        let alertcontl = UIAlertController(title: constants.APISNAme.Api_NAme, message: "Delete the users", preferredStyle: .alert)
        alertcontl.addTextField{(textfield) in
            textfield.placeholder = "Enter id No"
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        let DeleteAction = UIAlertAction(title: "Delete", style: .default){ _ in
            guard let idtext = alertcontl.textFields?.first?.text,
                  let id = Int(idtext) else{
                self.showAlert("Invalid id")
                return
            }
            self.deleteuser(id : id)
        }
        alertcontl.addAction(cancelAction)
        alertcontl.addAction(DeleteAction)
        self.present(alertcontl, animated: true)
        
    }
    
    func deleteuser(id: Int){
        self.deleteviewlist.deleteproduct(id: id){[weak self] in
            self?.listproducts.removeAll()
            self?.deleteproduct = (self?.deleteviewlist.deletebody)!
            DispatchQueue.global().async {
                self?.fetchListObject()
                self?.showAlert("user deleted successfully")
                
            }
            
        }
        
        
    }
    
    func ADDobjects() {
        if isNetworkReachable() {
            let alertcontroller = UIAlertController(title: constants.APISNAme.Api_NAme, message: "ADD the objects", preferredStyle: .alert)
            
            alertcontroller.addTextField { (textfield) in
                textfield.placeholder = "Enter the name"
            }
            alertcontroller.addTextField { (textfield) in
                textfield.placeholder = "Enter the year"
            }
            alertcontroller.addTextField { (textfield) in
                textfield.placeholder = "Enter the price"
            }
            alertcontroller.addTextField { (textfield) in
                textfield.placeholder = "Enter the CPU model"
            }
            alertcontroller.addTextField { (textfield) in
                textfield.placeholder = "Enter the hard disk size"
            }
            
            let cancel = UIAlertAction(title: "Cancel", style: .cancel) { _ in
                // Handle cancel action if needed
            }
            
            let save = UIAlertAction(title: "SAVE", style: .default) { (action) in
                guard let naming = alertcontroller.textFields?[0].text, !naming.isEmpty else {
                    self.showAlert("Name is required")
                    return
                }
                guard let year = alertcontroller.textFields?[1].text, !year.isEmpty else {
                    self.showAlert("Year is required")
                    return
                }
                guard let price = alertcontroller.textFields?[2].text, let pricing = Double(price), !price.isEmpty else {
                    self.showAlert("Price is required and should be a valid number")
                    return
                }
                guard let cpumodel = alertcontroller.textFields?[3].text, !cpumodel.isEmpty else {
                    self.showAlert("CPU model is required")
                    return
                }
                guard let harddisk = alertcontroller.textFields?[4].text, !harddisk.isEmpty else {
                    self.showAlert("Hard disk size is required")
                    return
                }
                
                self.AttachingviewModallist.CreateProduct(name: naming, year: year, price: pricing, Cpumodel: cpumodel, Harddisksize: harddisk)
                
                self.attachingproduct = self.AttachingviewModallist.AddProduct
                DispatchQueue.main.async {
                    self.fetchListObject()
                    self.showAlert("Added Object successfully")
                }
            }
            
            alertcontroller.addAction(cancel)
            alertcontroller.addAction(save)
            
           
            DispatchQueue.main.async {
                self.present(alertcontroller, animated: true, completion: nil)
            }
            
        } else {
            self.showAlert(AKErrorHandler.CommonErrorMessages.NO_INTERNET_AVAILABLE)
        }
    }

        
    } // end class
    

    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
   
    
    
    
    
    
    

