//
//  FetchViewModal.swift
//  ApiCalling
//
//  Created by user255655 on 6/17/24.
//

import Foundation
import SVProgressHUD
import Alamofire

class ListofObjects {
    
    var productfetch : [CreateModal]?
    
    func fetchproducts(completion : @escaping() -> ()){
        
         let sourceurl = constants.APIS.Baseurl + constants.APIS.Products
        SVProgressHUD.show()
        AF.request(sourceurl, method: .get , parameters: nil,encoding:  URLEncoding.default, headers: nil, interceptor:  nil )
            .response { resp in
                
                switch resp.result {
                    
             
                case .success(let data):
                    do{
                        let fetchdata = try JSONDecoder().decode([CreateModal].self , from: data!)
                        self.productfetch = fetchdata
                        completion()
                        SVProgressHUD.dismiss()
                        
                    } catch {
                        print(error.localizedDescription)
                    }
                    
                case .failure(let error):
                    print(error.localizedDescription)
                }
                
                
                
            }
        
        
        
        
    }
        
    
    
    
    
    
    
    
}
