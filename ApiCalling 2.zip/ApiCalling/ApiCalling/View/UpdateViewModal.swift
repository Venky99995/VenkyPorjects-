//
//  UpdateViewModal.swift
//  ApiCalling
//
//  Created by user255655 on 6/17/24.
//

import Foundation
 import Alamofire
import SVProgressHUD

class updateProductviewmodal{

    var updateproduct : UpdateMethod?
    
    func Updateproduct(id:Int,name:String ,year:String,price:Double,CpuModal:String,HarddiskSize:String,color :String,completion:@escaping()->() ){
        
        let sourceurl = constants.APIS.Baseurl + constants.APIS.Update + "/\(id ?? 0)"
        
        let params : [String: Any] = [
              
            "name":name,
            "data" : [
                "year" : year,
                "price" : price,
                "Cpumodal" : CpuModal,
                " Harddisksize" : HarddiskSize,
                "color" : color
            ]
           ]
        SVProgressHUD.show()
        AF.request(sourceurl , method: .put ,parameters: params,encoding: URLEncoding.default ,headers: nil, interceptor: nil)
            .response { resp in
                switch resp.result {
                    case .success(let data):
                    do {
                        let updatedata = try JSONDecoder().decode(UpdateMethod.self, from: data!)
                        print("update: \(updatedata)")
                        self.updateproduct = updatedata
                        completion()
                        SVProgressHUD.dismiss()
                        
                    }catch {
                        print(error.localizedDescription)
                    }
                case .failure(let error):
                    print(error.localizedDescription)
                }
                
                
                
                
            }
        
        
        
        
    }
    
    
}
