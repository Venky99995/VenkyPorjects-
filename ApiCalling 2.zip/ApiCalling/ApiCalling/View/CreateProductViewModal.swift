//
//  CreateProductViewModal.swift
//  ApiCalling
//
//  Created by user255655 on 6/17/24.
//

import Foundation
import SVProgressHUD
 import Alamofire
class createProductViewmodal {
    
    var AddProduct : PostMethod?
    
    func CreateProduct(name :String ,  year:String , price: Double,Cpumodel:String, Harddisksize: String ) {
        let params : [String :Any] = [
            
            "name" : name,
            "data" : [
                "year" : year,
                "price" : price,
                "Cpumodel": Cpumodel,
                "Harddisksize": Harddisksize ]
            ]
        let sourceurl = constants.APIS.Baseurl + constants.APIS.createproduct
        SVProgressHUD.show()
        AF.request(sourceurl, method: .post , parameters: params, encoding: URLEncoding.default , headers: nil, interceptor: nil )
            .validate()
            .response { resp in
                
                switch resp.result {
                    
                case .success(let data):
                    do {
                        let AddData = try JSONDecoder().decode(PostMethod.self, from: data!)
                        
                        print("ADD:\(AddData)" )
                        self.AddProduct = AddData
                        
                    } catch{
                            print(error.localizedDescription)
                        }
                    
                case .failure(let error):
                    print(error.localizedDescription)
                }
                
                
                
                
            }
        
        
        
        
        
        
    }
    
    
    
    
    
}
