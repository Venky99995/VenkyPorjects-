//
//  DeleteModal.swift
//  ApiCalling
//
//  Created by user255655 on 6/17/24.
//

import Foundation

struct DeleteMethod: Codable {

    let id: String?
    let name: String?
    let data: Data3?

}

struct Data3: Codable {

    let generation: String?
    let price: Int?

}
