//
//  ADDModal.swift
//  ApiCalling
//
//  Created by user255655 on 6/17/24.
//

import Foundation

struct PostMethod: Codable {

    let name: String
    let data:Data1

}


struct Data1 : Codable {

    let year: Int?
    let price: Double
    let CPUmodel: String
    let Harddisksize: String

}
