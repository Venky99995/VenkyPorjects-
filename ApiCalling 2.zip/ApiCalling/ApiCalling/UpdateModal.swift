//
//  UpdateModal.swift
//  ApiCalling
//
//  Created by user255655 on 6/17/24.
//

import Foundation

struct UpdateMethod: Codable {

    let name: String?
    let data: Data?

}


struct Data2: Codable {

    let year: Int?
    let price: Double?
    let CPUmodel: String?
    let Harddisksize: String?
    let color: String?

}
